import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoffeeItem } from './coffee-item';

describe('CoffeeItem', () => {
  let component: CoffeeItem;
  let fixture: ComponentFixture<CoffeeItem>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CoffeeItem],
    }).compileComponents();

    fixture = TestBed.createComponent(CoffeeItem);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

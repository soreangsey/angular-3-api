import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';
import { Observable } from 'rxjs';

import { Movie } from '../../models/movie';

@Service()
export class MovieService {

  private httpClient = inject(HttpClient);

  private APIURL =
    'https://api.sampleapis.com/movies/scifi-fantasy';

  getAll(): Observable<Movie[]> {
    return this.httpClient.get<Movie[]>(this.APIURL);
  }

  getById(id: number): Observable<Movie> {
    return this.httpClient.get<Movie>(`${this.APIURL}/${id}`);
  }
}
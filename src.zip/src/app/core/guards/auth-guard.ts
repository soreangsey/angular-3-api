import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { AuthService } from '../services/auth/auth-service';

export const authGuard: CanActivateFn = (route, state) => {

  const authService = inject(AuthService);
  const router = inject(Router);

  console.log('Guard - isLogged:', authService.isLogged());

  if (authService.isLogged()) {
    return true;
  }

  return router.createUrlTree(['/login']);
};